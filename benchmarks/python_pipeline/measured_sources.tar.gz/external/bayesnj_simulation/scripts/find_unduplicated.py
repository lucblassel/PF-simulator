# pyright: reportAny=false

import os
from collections.abc import Iterable
from glob import glob
from pathlib import Path

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from tqdm import tqdm


def has_duplicates(msa: list[SeqRecord]):
    return len(set(x.seq for x in msa)) != len(msa)


def find_unduplicated(msa: list[SeqRecord], ln: int):
    tot_len = len(msa[0])
    if tot_len == ln:
        return has_duplicates(msa)

    for offset in range(tot_len - ln):
        sub = [x[offset : offset + ln] for x in msa]
        if not has_duplicates(sub):
            return offset
    return None


def seq_is_tip(rec: SeqRecord) -> bool:
    return rec.id.startswith("T")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Find unduplicated seqgments of length L in alignments"
    )
    _ = parser.add_argument("root")
    _ = parser.add_argument("outdir")
    _ = parser.add_argument("-l", "--length", type=int, default=500)
    _ = parser.add_argument("-n", "--no_gaps", action="store_true")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    if args.no_gaps:
        all_msas = glob(f"{args.root}/*fa")
    else:
        all_msas = glob(f"{args.root}/*untrimmed")

    for path in tqdm(all_msas):
        if args.no_gaps:
            filename = Path(path).name
        else:
            filename = Path(path).name.strip(".untrimmed")

        msa: Iterable[SeqRecord] = list(SeqIO.parse(path, format="fasta"))
        tips = list(filter(seq_is_tip, msa))

        if has_duplicates(tips):
            continue

        if (offset := find_unduplicated(tips, ln=args.length)) is not None:
            sub: Iterable[SeqRecord] = (x[offset : offset + args.length] for x in msa)
            _ = SeqIO.write(sub, os.path.join(args.outdir, filename), format="fasta")
